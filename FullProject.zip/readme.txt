Steps to launch Program:

1) Start Coppelia;
2) Open 3D_Model_482_Project_v20_MatlabFeedback.ttt;
3) Be sure the sample time is at 10ms;
3) In the Coppelia interface open the BlueZero Interface Add-ons->b0RemoteApiServer;
4) Wait for the b0_resolver.exe to start;
5) Start the Matlab script torque_control_coppelia;