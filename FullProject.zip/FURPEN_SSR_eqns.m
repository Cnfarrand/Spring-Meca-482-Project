% State Space Representation
    D__r = 0.24e-2;
    D__p = 0.24e-2;

J__t = J__r*J__p + m__p*(L__p/2)^2*J__r + J__p*m__p*L__r^2;
A = [0 0 1 0;
    0 0 0 1;
    0 m__p^2*(L__p/2)^2*L__r*g/J__t -D__r*(J__p+m__p*(L__p/2)^2)/J__t -m__p*(L__p/2)*L__r*D__p/J__t;
    0 m__p*g*(L__p/2)*(J__r+m__p*L__r^2)/J__t -m__p*(L__p/2)*L__r*D__r/J__t -D__p*(J__r+m__p*L__r^2)/J__t];
B = [0; 0; (J__p+m__p*(L__p/2)^2)/J__t; m__p*(L__p/2)*L__r/J__t];
C = [1 0 0 0];
D = [0];
% Load into state-space system
B = k__g * k__t * B / r__m;
A(3,3) = A(3,3) - k__g^2*k__t*k__m/r__m*B(3);
A(4,3) = A(4,4) - k__g^2*k__t*k__m/r__m*B(4);
sys_FURPEN_ol = ss(A,B,C,D); % Open loop system model
